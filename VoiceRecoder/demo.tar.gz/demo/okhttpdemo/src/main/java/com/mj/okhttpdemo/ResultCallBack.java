package com.mj.okhttpdemo;

import java.io.IOException;

import okhttp3.Response;

/**
 * Created by liuwei on 7/3/17.
 */

public abstract class ResultCallBack {
    //成功的回传
    abstract String  onSuccess( Response okstr);

    //失败的回传
    abstract String onFailure(IOException failstr);

}
