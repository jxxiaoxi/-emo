package com.mj.okhttpdemo;

/**
 * Created by liuwei on 7/1/17.
 */

public abstract class RequestCallBack<T> {
//    /**
//     * 在请求之前的方法，一般用于加载框展示
//     *
//     * @param request
//     */
//    public void onBefore(Request request) {
//    }
//
//    /**
//     * 在请求之后的方法，一般用于加载框隐藏
//     */
//    public void onAfter() {
//    }
//
//    /**
//     * 请求失败的时候
//     *
//     * @param request
//     * @param e
//     */
//    public abstract void onError(Request request, Exception e);
//
//    /**
//     *
//     * @param response
//     */
//    public abstract void onResponse(T response);
}
