package com.mj.okhttpdemo;


import android.os.Bundle;

import java.io.File;
import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.Response;


public class MainActivity extends BaseActivity {
    private static final String TAG = "MainActivity";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RequestBody fileBody = RequestBody.create(MediaType.parse("video/3gp"), new File(""));
        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", "test.mp4", fileBody)
                .addFormDataPart("description", "监控视频上传")
                .build();
        OkHttpHelper.getOkHttpInstance(this).uploadFiles("url", requestBody, new ResultCallBack() {

            @Override
            String onSuccess(Response okstr) {
                return null;
            }

            @Override
            String onFailure(IOException failstr) {
                return null;
            }
        });
    }

}
