package com.mj.okhttpdemo;

/**
 * Created by liuwei on 7/3/17.
 */

public interface OkHttpInterface {
    //成功的回传
    void onSuccess();

    //失败的回传
    void onFailure();

    //进度回传
    void onProgress();

    //开始上传或者下载
    void onStart();

    //结束下载或者上传
    void onEnd();
}
